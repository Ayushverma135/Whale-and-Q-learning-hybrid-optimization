package datacenter;

/**
 * @author : LA4AM12
 * @create : 2023-03-15 09:40:28
 * @description : Datacenter type
 */
public enum Type {
	LOW,
	MEDIUM,
	HIGH
}